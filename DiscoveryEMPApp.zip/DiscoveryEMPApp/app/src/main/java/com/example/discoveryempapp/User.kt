package com.example.discoveryempapp

data class User(var fname:String?=null,var idno:String?=null,var etno:String?=null,var position:String?=null,var pcode:String?=null)
