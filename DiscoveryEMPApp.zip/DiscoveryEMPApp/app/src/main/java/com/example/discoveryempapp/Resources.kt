package com.example.discoveryempapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Resources : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resources)
    }
}