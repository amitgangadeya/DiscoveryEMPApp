package com.kerols.pdfconverter;

/**
 *
 * @see  Value for select Page Size
 * */

public enum Value {

     PAGE_A4 ,
     PAGE_A3 ,
     PAGE_A2 ,
     PAGE_A1 ,
     IMAGE_SIZE ,
     DEFAULT ,

}


