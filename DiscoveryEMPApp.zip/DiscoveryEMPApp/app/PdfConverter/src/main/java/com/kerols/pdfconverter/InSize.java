package com.kerols.pdfconverter;

/**
 *
 * @see  InSize for select Image Size
 * */

public enum InSize {

    FULL_PAGE_SIZE,
    IMAGE_SIZE ,
    DEFAULT ,
}
